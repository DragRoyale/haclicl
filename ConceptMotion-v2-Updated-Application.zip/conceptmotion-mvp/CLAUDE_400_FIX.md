# Claude Sonnet 5.5 HTTP 400 fix

The original ConceptMotion API request included `temperature: 0.3`, which is not supported by `claude-sonnet-5-5` and causes HTTP 400.

This version removes that setting, increases the token allowance, and displays Anthropic's actual error message if a different problem occurs.

## Install

- If you already extracted and configured ConceptMotion, **do not replace your `.env` file**.
- Copy the patched `lesson_engine.py` and `app.py` into your existing `conceptmotion-mvp` folder, replacing those files.
- Close the old server (Ctrl+C in the console) and restart `start-windows.bat`.
- Re-run the backpropagation prompt; no slides are required for this test.
- If an error persists, copy the new error message (omit any credentials).

## Testing

15 local tests passed, including a mock Claude response and a simulated 400 with a useful error message. A live paid Claude API request was not performed.
