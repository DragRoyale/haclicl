# ConceptMotion — 2-minute hackathon demo script

### 0:00–0:15 — The problem
"Students sit through lectures full of graphs and equations, but they often can't *see* what the professor means. Existing AI assistants mostly reply with more text."

### 0:15–0:32 — Show difficult source material
Open a math lecture PDF and explain that students can upload slides and record a short explanation from the professor (with permission). Show the selected topic and PDF uploader. Mention Claude reads both text and the first three slide images when configured.

### 0:32–0:55 — The director
Click **Generate visual lesson**. Show the structured storyboard: every scene has a specific teaching goal, animation type, and narration. Highlight that the AI never executes arbitrary generated animation code.

### 0:55–1:24 — The aha moment
Play the SIR population scene, jump to the S → I → R compartments, then jump to a mathematical explanation. Explain how the animation tracks the professor's conceptual structure. Switch to the integral example, where rectangles approximate the area under a curve.

### 1:24–1:42 — Generative media and narration
Show the optional fal cinematic clip and ElevenLabs transcription/voice integration **only if genuinely configured and working**. If not, clearly label it a planned integration and demonstrate the deterministic core. Do not claim live sponsor API success if no request completed.

### 1:42–2:00 — The output
Click **Export MP4** or show a previously rendered 45-second lesson. Explain: "ConceptMotion transforms a difficult lecture into an explanation you can watch, understand, and review." Close with the architectural novelty: AI storyboard + accurate scientific animation + optional generative media.

**Demo prep:** Save the working MP4 in advance. If rendering in the recording is sped up, label the video and disclose actual generation time. Make sure the repo contains code written during the permitted hackathon period and that all sponsor integrations shown genuinely work.
