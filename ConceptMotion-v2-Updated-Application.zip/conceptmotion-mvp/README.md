# ConceptMotion — From lecture to understanding

A hackathon MVP that converts a lecture topic, PDF slides and optional professor audio into a **30–60 second, visually precise educational animation**. It takes inspiration from scientific 3D motion graphics: near-black backgrounds, glowing blue/amber/teal shapes, animated populations, equations and diagrams.

The app works **without AI keys in demo mode**. With a Claude API key, the model can plan new storyboards using the student's topic, the professor's transcript and both text and images from lecture slides. The renderer only accepts predefined animation types; it never runs code invented by an LLM.

![ConceptMotion screenshot](docs/studio-preview.png)

## What already works

- Polished responsive editor, animated portrait video preview, play/pause, timeline scrubbing, clickable storyboard scenes.
- Five complete offline example lessons: SIR epidemic model, integrals, derivatives, gradient descent, neural networks.
- Ten deterministic animation scene templates: `population`, `compartments`, `diffusion`, `riemann`, `slope`, `landscape`, `network`, `vectors`, `equation`, `generic`.
- FastAPI `/api/lesson`: Claude storyboard planner when configured, otherwise a clearly marked demo template.
- PDF slide upload: text extraction for the first 20 pages and images of the first 3 pages for Claude vision.
- ElevenLabs Scribe endpoint: record a short lecturer explanation or upload audio. Manual transcript entry always works.
- Optional ElevenLabs text-to-speech narration during MP4 export.
- Optional fal WAN 2.7 text-to-video generation of a 5-second cinematic clip; the clip can be included in the final MP4 if completed successfully.
- MP4 export using **the exact same canvas drawing engine** as the preview via headless Chromium + FFmpeg.
- Exports run as background jobs with status polling; the UI is responsive while rendering.
- 13 automated tests, covering scene validation, health, demo mode, malicious scene types, PDF handling and invalid exports.

## Run on Windows 11 (Python 3.12)

**Prerequisites:** Python 3.12, internet access for dependency installation. FFmpeg is needed **only for MP4 export**. Install FFmpeg with `winget install Gyan.FFmpeg` or use another FFmpeg distribution, then reopen your terminal to refresh PATH.

1. Extract the ZIP to a folder, for example `C:\Users\YourName\Desktop\conceptmotion-mvp`.
2. Double-click `start-windows.bat`. On first run, it creates `.venv`, installs packages, and downloads Playwright Chromium. Later runs do not have to redownload browsers.
3. Open **http://127.0.0.1:8000**.
4. Click **SIR model** to explore the supplied reference-inspired animation. Click **Export MP4** to produce a video.
5. Optionally add keys to `.env` and restart the server to use the live AI services.

> If your Windows machine cannot find `py -3.12`, modify `start-windows.bat` to use your installed Python executable. The `.env` file and generated `output/` folders are excluded from Git.

### Alternative manual setup

```powershell
cd conceptmotion-mvp
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m playwright install chromium
copy .env.example .env
python -m uvicorn app:app --host 127.0.0.1 --port 8000
```

To test:

```powershell
python -m pip install pytest httpx
python -m pytest -q tests
```

## API keys & sponsor integrations

`.env.example` includes the available settings. Copy it to `.env` and fill in any keys you have:

```ini
ANTHROPIC_API_KEY=your-claude-key
CLAUDE_MODEL=claude-sonnet-5-5
ELEVENLABS_API_KEY=your-elevenlabs-key
ELEVENLABS_VOICE_ID=JBFqnCBsd6RMkjVDRZzb
FAL_KEY=your-fal-key
```

**Claude:** reads the user topic, a professor's transcript, PDF slide text and first three slide images, and generates a storyboard JSON. The server validates and caps every scene. When Claude is not configured, the sample generator will show a **Demo template** badge. Other topics get a generic demo and are **not genuinely understood** without the Claude key.

**ElevenLabs:** short audio clips go to the Scribe speech-to-text API. Tick **ElevenLabs voice** during MP4 export to generate a narrated track. No key means you can paste professor speech manually and export silent animations.

**fal:** **Generate fal clip** submits a 5-second WAN 2.7 text-to-video job. The generated video is shown in its own preview. Once complete, **Include fal clip in MP4** becomes available and it can be appended as a cinematic B-roll ending, provided the final video stays within one minute. The core scientific animation remains deterministic.

These integrations were written against public API documentation, but **have not been validated with real account keys in this environment**. Sponsor credit, billing and model access may vary by account.

## Architecture

```mermaid
flowchart TD
    A[Topic / PDF slides / professor audio] --> B[PDF text + slide image extraction / ElevenLabs transcription]
    B --> C[Claude teaching director]
    C --> D[Validated 30-60s storyboard JSON]
    D --> E[Deterministic Canvas motion scene templates]
    D --> F[Optional fal generated cinematic clip]
    D --> G[Optional ElevenLabs narration]
    E --> H[Playwright + FFmpeg exporter]
    F --> H
    G --> H
    H --> I[MP4 + interactive preview]
```

### Files

| File | Role |
|---|---|
| `app.py` | FastAPI server, PDF, transcription, sponsor APIs, export jobs |
| `lesson_engine.py` | Claude prompt and strict storyboard/scene validation |
| `static/visuals.js` | Deterministic animation scenes: exact same code in preview and MP4 |
| `static/app.js` | Editor interactions, uploads, controls, job polling |
| `static/styles.css` | Responsive dark-blue interface |
| `static/index.html` | Accessible editor layout |
| `render.py` | Headless local Canvas-to-FFmpeg MP4 renderer |
| `samples/*.json` | Five authored reference lessons |
| `tests/test_mvp.py` | Validation and API smoke tests |
| `DEMO_SCRIPT.md` | Two-minute hackathon pitch/video plan |

## API endpoints

- `GET /api/health` — configuration and render dependencies.
- `GET /api/samples` — offline lessons.
- `POST /api/lesson` — topic, slides, transcript, slide_images to Claude/storyboard.
- `POST /api/pdf` — PDF text + first three images.
- `POST /api/transcribe` — ElevenLabs audio transcription.
- `POST /api/fal` — optional cinematic clip generation.
- `POST /api/export` — asynchronous MP4, optional voice/fal outro.
- `GET /api/jobs/{id}` — job status.
- `GET /api/download/{id}` — finished MP4.

## Limitations to be explicit about in the demo

- This is a **template-based renderer**, not a model that can draw absolutely any scientific concept correctly. Unknown topics fall back to basic diagrams. Expanding the scene library expands coverage.
- The mathematical animations use fixed examples (e.g. \(x^2\) for integrals and derivatives). The model should not claim that a generic template is an exact representation of an unrelated equation.
- The PDF pipeline extracts text from up to 20 pages, and includes slide images from the **first three** pages only. No whole-document OCR or real-time slide tracking yet.
- The lecture companion supports **short audio recordings**, not continuous live audio streaming.
- Voice alignment currently uses the lesson's approximate timings, not per-word timestamps.
- Canvas MP4 export is CPU-intensive and requires FFmpeg and a Playwright-supported Chromium browser; the preview plays immediately.
- Live Claude, ElevenLabs and fal APIs will incur provider usage charges when keys are added. The fal video endpoint is external and may be slow.
- The server is bound to `127.0.0.1`. **Do not expose it publicly with paid API keys without authentication, rate limits, abuse controls and stronger input validation**.
- Scientific accuracy still requires evaluation against known examples and human review, especially for arbitrary AI-generated lessons.

## Next engineering priorities

1. **Reliability:** add speech timestamps per scene, render-cache, job queue persistence, and strong error states.
2. **Breadth:** 3D vector transformation, probability distributions, mechanics, dynamic graph algorithms, neuron firing.
3. **Real-time lecture companion:** incremental transcription, slide matching, one-click microvisualization.
4. **Sponsor scoring:** collect and compare before/after student explanations; build a genuine interactive ElevenLabs voice agent; integrate fal clips into the storyboard timeline itself rather than only as B-roll.

Built for a short hackathon prototype, not as a production education service.

---

## ConceptMotion v2 — Intuition-first mathematical derivation (November 2026)

The v2 patch retains all five original lessons and adds a curated **100-second, nine-scene arc-length derivation**. Select **★ Arc length (100s)** under Quick Demos. It is also loaded by default on launch.

- **Intuition:** bent string, short rulers, and a local Pythagorean triangle before the formula.
- **Timed mathematical steps:** six stages from chord approximation through slope substitution, factoring, and the limit to the integral.
- **Visual formula anchors:** relevant curves or triangles remain visible alongside equations.
- **Typeset mathematics:** local, browser-native MathML; no CDN or KaTeX/npm dependency.
- **Highlighting:** the exact equation part being explained changes to gold at storyboard event timestamps.
- **Captions:** bold, highlighted subtitles accompany every scene.
- **MP4:** the Playwright exporter captures the combined Canvas and MathML stage, rather than only the Canvas.
- **Voice:** when ElevenLabs is configured, narration is generated per scene and stretched/padded to match storyboard boundaries. Requires `ffmpeg` and `ffprobe`.

### How to run

Run `start-windows.bat` on Windows, or install `requirements.txt`, `playwright install chromium`, and start `uvicorn app:app --host 127.0.0.1 --port 8000`. The default scene is the arc-length lesson. Use the play controls or click storyboard scenes to seek, then **Export MP4** to render your own file.

### Files added/updated

- `lessons/arc_length_formula.json`: complete nine-scene reference lesson.
- `static/arc_length.js`: timestamp-driven geometry scenes for the curved string, chords, triangles, local slope, and convergence.
- `static/math.js`: browser-native MathML rendering, structured equation term highlights, highlighted subtitle overlay.
- `lesson_engine.py`: backward-compatible v2 schema validation and intuition-first Claude system prompt.
- `static/visuals.js`, `static/app.js`, `static/index.html`, `static/styles.css`: new scene type, preview layer, and lesson picker.
- `render.py`: identical overlay capture in the exported MP4.
- `app.py`: registered canonical lesson and scene-aligned ElevenLabs speech.
- `tests/test_arc_length.py`: v2 acceptance tests.

**Known limitations:** The canonical 100-second lesson is hand-authored; Claude still generates shorter lessons using the existing visual templates and does not yet invent new arbitrary Manim/3D scenes. Mathematical typesetting supports the restricted symbols used in the reference lesson and common expressions, not every possible LaTeX macro. Full symbolic matching/morphing is not implemented; equations use timestamp-driven crossfades between whole expressions. Subtitle timing follows scene/event timestamps, not word-level audio alignment. External Claude, ElevenLabs, and fal calls require working API keys and have not been live-tested as part of this package.
