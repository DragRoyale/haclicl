# Two-minute demo walkthrough — ConceptMotion v2

1. **0:00–0:20 — Problem.** Show a dense arc-length formula on screen; explain that a formula by itself doesn't build intuition.
2. **0:20–0:35 — Source to lesson.** Open the studio and show the arc-length example selected (the curated, offline demonstration). Mention that the broader application can also accept a lecture topic, PDF slides, and optional speech transcript.
3. **0:35–1:05 — Intuition.** Play the bent-string analogy and short-ruler approximation, then skip to the magnified right triangle.
4. **1:05–1:35 — Mathematics.** Seek to the slope and substitution scenes. Show highlighted variables changing gold exactly when explained, followed by the short-segment limit turning into an integral.
5. **1:35–1:50 — Export.** Show the MP4 export and play a short resulting clip. Be clear that the 100s arc-length demo is a curated lesson rather than a generated arbitrary Manim script.
6. **1:50–2:00 — Integration.** Highlight the v2 validated storyboard, optional Claude/ElevenLabs/fal integrations, and end with the product vision: lecture-to-understanding visual explanations.

Avoid implying sponsor APIs were live-tested unless your team has actually made a successful authenticated call. Tell judges when footage is sped up.
