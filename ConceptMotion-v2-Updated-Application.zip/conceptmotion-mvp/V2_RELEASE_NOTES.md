# ConceptMotion v2 — Release notes

## Included

1. A complete 100-second arc-length lesson with nine timed stages, intuition-first narration and a rigorous right-triangle derivation.
2. New storyboard fields: `schema_version`, `lesson_id`, `scene_id`, `pedagogy_role`, `learning_goal`, `analogy`, `subtitle` with highlighted phrases, `equations` with addressable parts, and timed `events`.
3. In-browser mathematical formatting using native MathML. Gold highlights activate/deactivate at specified timestamps, including within square roots.
4. A new Canvas engine for curve straightening, chord approximations, right triangles, slope relations and finite sums approaching the integral.
5. The browser preview and MP4 exporter draw the same composite stage.
6. Optional scene-by-scene ElevenLabs voice generation with timing adjustment during export.
7. All five original sample lessons and original endpoints remain available.

## Run

Extract the folder, keep your private `.env` in the folder if configured, then run `start-windows.bat`. Test **★ Arc length (100s)** first, then export. For programmatic tests: `python -m pytest -q tests`. For a quick demo without API keys, use the canonical arc-length lesson.

## Important limitations

- The arc-length storyboard is a *curated template*. AI-generated lessons still use the existing limited scene library. This is not a universal generated Manim engine.
- Equation transitions use time-based crossfades rather than true glyph-by-glyph symbolic morphs.
- ElevenLabs audio is optional and unverified without a live account; scene audio is fitted to timeline durations but not aligned at the word level.
- The 100-second demo exceeds the 60-second general-lesson limit by design.
