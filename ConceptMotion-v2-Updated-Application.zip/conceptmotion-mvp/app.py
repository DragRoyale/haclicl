"""ConceptMotion hackathon server: self-contained demo + optional sponsor APIs."""
from __future__ import annotations
import base64
import io
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import quote, urlparse

import requests
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from lesson_engine import get_demo, generate, validate_lesson

BASE = Path(__file__).resolve().parent
OUT = BASE / "output"
OUT.mkdir(exist_ok=True)
app = FastAPI(title="ConceptMotion", version="0.1.0")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
executor = ThreadPoolExecutor(max_workers=2)
JOBS: dict[str, dict] = {}
job_lock = threading.Lock()

# Env file parser: avoids requiring python-dotenv for a short hackathon build.
def load_env():
    env = BASE / ".env"
    if env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, val = line.split("=", 1)
            os.environ.setdefault(k.strip(), val.strip().strip('"').strip("'"))

load_env()

class LessonRequest(BaseModel):
    topic: str = Field(default="How does a disease spread?", max_length=400)
    slides: str = Field(default="", max_length=20000)
    transcript: str = Field(default="", max_length=15000)
    slide_images: list[str] = Field(default_factory=list, max_length=3)

class ExportRequest(BaseModel):
    lesson: dict
    use_voice: bool = False
    portrait: bool = True
    quality: str = "preview"
    fal_job_id: str | None = None

class FalRequest(BaseModel):
    prompt: str = Field(min_length=12, max_length=1500)
    duration: int = Field(default=5, ge=2, le=15)

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health():
    return {"ok": True, "features": {
        "claude": bool(os.getenv("ANTHROPIC_API_KEY")),
        "elevenlabs": bool(os.getenv("ELEVENLABS_API_KEY")),
        "fal": bool(os.getenv("FAL_KEY")),
        "ffmpeg": bool(shutil.which(os.getenv("FFMPEG_PATH", "ffmpeg"))),
        "preview": True,
    }}

@app.get("/api/samples")
def samples():
    from lesson_engine import sample
    return {k: sample(k) for k in ["disease_model", "integral", "derivative", "gradient_descent", "neural_network", "arc_length_formula"]}

@app.post("/api/lesson")
def create_lesson(body: LessonRequest):
    try:
        lesson, provider = generate(body.topic, body.transcript, body.slides, body.slide_images)
    except requests.HTTPError as exc:
        # Anthropic 4xx errors include a useful error.message (e.g. unsupported parameters).
        # Show the explanation without exposing credentials or full request contents.
        response = exc.response
        status = response.status_code if response is not None else "unknown"
        message = "Request rejected by Claude"
        if response is not None:
            try:
                raw = response.json()
                message = str(raw.get("error", {}).get("message", message))
            except (ValueError, AttributeError, TypeError):
                pass
        raise HTTPException(502, f"Claude API returned {status}: {message[:350]}") from exc
    except requests.RequestException as exc:
        raise HTTPException(502, f"Claude connection failed: {type(exc).__name__}") from exc
    except ValueError as exc:
        raise HTTPException(502, str(exc)) from exc
    lesson["provider"] = provider
    lesson["source"] = {"topic": body.topic[:150], "has_slides": bool(body.slides), "has_transcript": bool(body.transcript)}
    return lesson

@app.post("/api/pdf")
async def parse_pdf(file: UploadFile = File(...)):
    if not (file.filename or "").lower().endswith(".pdf"):
        raise HTTPException(400, "Upload a PDF document")
    data = await file.read(12 * 1024 * 1024 + 1)
    if len(data) > 12 * 1024 * 1024:
        raise HTTPException(413, "The maximum PDF size is 12 MB")
    if not data.startswith(b"%PDF"):
        raise HTTPException(400, "Not a valid PDF")
    try:
        import fitz
        doc = fitz.open(stream=data, filetype="pdf")
        snippets = []
        images = []
        for page_num in range(min(len(doc), 20)):
            page = doc[page_num]
            text = page.get_text("text").strip()
            snippets.append(f"[Slide/Page {page_num + 1}]\n{text[:1600] if text else '[No extractable text: scanned or image-only slide]'}")
            if page_num < 3:
                pix = page.get_pixmap(matrix=fitz.Matrix(1.0, 1.0), alpha=False)
                # Keep each vision attachment within a small request budget.
                image_bytes = pix.tobytes("jpeg", jpg_quality=58)
                if len(image_bytes) <= 1_000_000:
                    images.append(base64.b64encode(image_bytes).decode("ascii"))
        pages = len(doc)
    except Exception as exc:
        raise HTTPException(400, f"Couldn't parse PDF: {str(exc)[:200]}") from exc
    return {"pages": pages, "text": "\n\n".join(snippets)[:20000], "filename": file.filename,
            "images": images,
            "warning": "The first three slide images are also supplied to Claude for visual understanding when the Claude API is connected."}

@app.post("/api/transcribe")
async def transcribe(file: UploadFile = File(...)):
    key = os.getenv("ELEVENLABS_API_KEY", "")
    if not key:
        raise HTTPException(400, "Set ELEVENLABS_API_KEY to enable speech transcription. You can paste the transcript manually without a key.")
    data = await file.read(15 * 1024 * 1024 + 1)
    if len(data) > 15 * 1024 * 1024:
        raise HTTPException(413, "Audio file must be under 15 MB")
    if not data:
        raise HTTPException(400, "No recording attached")
    try:
        result = requests.post("https://api.elevenlabs.io/v1/speech-to-text",
            headers={"xi-api-key": key},
            data={"model_id": "scribe_v1"},
            files={"file": (Path(file.filename or "lecture.webm").name, data, file.content_type or "audio/webm")},
            timeout=90)
        result.raise_for_status()
        return {"text": result.json().get("text", "")}
    except requests.RequestException as exc:
        raise HTTPException(502, f"ElevenLabs transcription error: {str(exc)[:250]}") from exc


def generate_voice(lesson: dict, job_folder: Path) -> Path | None:
    """Synthesize and align each narration to its own scene (not a 1800-char truncation).

    Timing is based on the storyboard. If speech exceeds the scene, atempo adjusts it;
    if it's shorter, silence is added. Generated scene audio starts at its scene boundary.
    """
    key = os.getenv("ELEVENLABS_API_KEY", "").strip()
    if not key:
        return None
    scenes = lesson.get("scenes", [])
    if not any(str(scene.get("narration", "")).strip() for scene in scenes):
        return None
    ffmpeg = os.getenv("FFMPEG_PATH", "ffmpeg")
    probe = os.getenv("FFPROBE_PATH", "ffprobe")
    voice = os.getenv("ELEVENLABS_VOICE_ID", "JBFqnCBsd6RMkjVDRZzb")

    def synthesize(index_scene):
        index, scene = index_scene
        text = str(scene.get("narration", "")).strip()
        if not text:
            return index, None
        response = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{quote(voice)}",
            headers={"xi-api-key": key, "content-type": "application/json", "accept": "audio/mpeg"},
            json={"text": text[:650], "model_id": "eleven_multilingual_v2",
                  "voice_settings": {"stability": 0.55, "similarity_boost": 0.72}},
            timeout=90,
        )
        response.raise_for_status()
        clip = job_folder / f"voice-{index:02d}.mp3"
        clip.write_bytes(response.content)
        return index, clip

    # Parallelize independent scene narration, limiting concurrency to avoid bursts.
    with ThreadPoolExecutor(max_workers=3) as voices:
        files = dict(voices.map(synthesize, enumerate(scenes)))

    clips = []
    for index, scene in enumerate(scenes):
        scene_duration = float(scene.get("duration", 8))
        clip = files[index]
        out = job_folder / f"aligned-{index:02d}.wav"
        filters = []
        if clip is not None:
            probe_result = subprocess.run(
                [probe, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(clip)],
                capture_output=True, text=True, timeout=15, check=True,
            )
            recorded_duration = float(probe_result.stdout.strip())
            factor = max(1.0, recorded_duration / max(scene_duration - .1, 1))
            # FFmpeg atempo supports factors between 0.5 and 2; chain when needed.
            while factor > 2:
                filters.append("atempo=2")
                factor /= 2
            if factor > 1.015:
                filters.append(f"atempo={factor:.6f}")
            filters.extend(["apad", f"atrim=duration={scene_duration:.4f}"])
            cmd = [ffmpeg,"-hide_banner","-loglevel","error","-y","-i",str(clip),"-af",",".join(filters),"-ar","44100","-ac","1",str(out)]
        else:
            cmd = [ffmpeg,"-hide_banner","-loglevel","error","-y","-f","lavfi","-i","anullsrc=r=44100:cl=mono","-t",str(scene_duration),"-ar","44100","-ac","1",str(out)]
        subprocess.run(cmd,check=True,capture_output=True,timeout=45)
        clips.append(out)
    manifest = job_folder / "voice-concat.txt"
    manifest.write_text("\n".join(f"file '{file.name}'" for file in clips) + "\n", encoding="utf-8")
    merged = job_folder / "narration.m4a"
    subprocess.run([ffmpeg,"-hide_banner","-loglevel","error","-y","-f","concat","-safe","0","-i",str(manifest),
                    "-c:a","aac","-b:a","160k",str(merged)],check=True,capture_output=True,timeout=90)
    return merged


def set_job(id_: str, **kwargs):
    with job_lock:
        JOBS[id_].update(kwargs)


def download_fal_clip(url: str, dest: Path):
    host = urlparse(url).hostname or ""
    # Never download arbitrary user-supplied URLs from the server.
    if not (host == "fal.media" or host.endswith(".fal.media") or host == "fal.ai" or host.endswith(".fal.ai")):
        raise ValueError(f"Unexpected fal video host: {host[:80]}")
    if not url.startswith("https://"):
        raise ValueError("fal output is not HTTPS")
    with requests.get(url, stream=True, timeout=50, allow_redirects=False) as response:
        response.raise_for_status()
        with dest.open("wb") as target:
            count = 0
            for chunk in response.iter_content(chunk_size=1024*512):
                count += len(chunk)
                if count > 80*1024*1024:
                    raise ValueError("fal clip exceeds 80 MB")
                target.write(chunk)


def append_fal_clip(base: Path, fal_video: Path, final: Path, duration: float, extra: float, quality: str):
    ffmpeg = os.getenv("FFMPEG_PATH", "ffmpeg")
    w,h,fps = (360,640,15) if quality=="preview" else (540,960,24)
    has_audio = subprocess.run(["ffprobe","-v","error","-select_streams","a:0","-show_entries","stream=index","-of","csv=p=0",str(base)],capture_output=True,text=True).stdout.strip()
    f = (f"[0:v]fps={fps},scale={w}:{h},setsar=1,setpts=PTS-STARTPTS[v0];"
         f"[1:v]fps={fps},scale={w}:{h}:force_original_aspect_ratio=decrease,"
         f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,trim=duration={extra:.2f}[v1];"
         "[v0][v1]concat=n=2:v=1:a=0[v]")
    cmd = [ffmpeg,"-hide_banner","-loglevel","error","-y","-i",str(base),"-i",str(fal_video),"-filter_complex",f,"-map","[v]"]
    if has_audio:
        cmd += ["-map","0:a:0","-af","apad","-c:a","aac","-b:a","128k"]
    cmd += ["-c:v","libx264","-preset","veryfast","-crf","25","-pix_fmt","yuv420p","-movflags","+faststart","-t",f"{duration+extra:.2f}",str(final)]
    subprocess.run(cmd,check=True,capture_output=True,text=True,timeout=200)


def export_worker(id_: str, lesson: dict, use_voice: bool, portrait: bool, quality: str, fal_url: str | None):
    folder = OUT / id_
    folder.mkdir(exist_ok=True)
    try:
        set_job(id_, state="rendering", detail="Preparing lesson")
        (folder / "lesson.json").write_text(json.dumps(lesson, ensure_ascii=False), encoding="utf-8")
        audio = None
        if use_voice:
            set_job(id_, detail="Generating ElevenLabs narration")
            audio = generate_voice(lesson, folder)
        set_job(id_, detail="Rendering deterministic animation frames")
        initial_output = folder / ("lesson-base.mp4" if fal_url else "lesson.mp4")
        cmd = [sys.executable, str(BASE / "render.py"), "--lesson", str(folder / "lesson.json"),
            "--output", str(initial_output), "--quality", quality]
        if not portrait:
            cmd.append("--landscape")
        if audio:
            cmd += ["--audio", str(audio)]
        result = subprocess.run(cmd, cwd=BASE, capture_output=True, text=True, timeout=900)
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout)[-1100:])
        if fal_url:
            remaining = max(0, 60 - float(lesson["duration"]))  # Never extend 100s flagship
            extra = min(5, remaining)
            if extra >= 2:
                set_job(id_, detail="Adding the generated fal scene to the MP4")
                clip = folder / "fal-broll.mp4"
                download_fal_clip(fal_url, clip)
                append_fal_clip(initial_output, clip, folder / "lesson.mp4", float(lesson["duration"]), extra, quality)
            else:
                shutil.copy2(initial_output, folder / "lesson.mp4")
        set_job(id_, state="done", detail="Export finished", url=f"/api/download/{id_}")
    except Exception as exc:
        set_job(id_, state="error", detail=str(exc)[:900])

@app.post("/api/export")
def export_video(body: ExportRequest):
    if not shutil.which(os.getenv("FFMPEG_PATH", "ffmpeg")):
        raise HTTPException(400, "ffmpeg is required for MP4 export; preview remains available")
    try:
        lesson = validate_lesson(body.lesson)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    id_ = uuid.uuid4().hex[:16]
    with job_lock:
        JOBS[id_] = {"state": "queued", "detail": "Queued for rendering", "url": None, "type": "export"}
    fal_url = None
    if body.fal_job_id:
        clip_job = JOBS.get(body.fal_job_id)
        if clip_job and clip_job.get("type") == "fal" and clip_job.get("state") == "done":
            fal_url = clip_job.get("url")
    executor.submit(export_worker, id_, lesson, body.use_voice, body.portrait, body.quality, fal_url)
    return {"id": id_, "state": "queued"}


def fal_worker(id_: str, prompt: str, duration: int):
    try:
        set_job(id_, state="rendering", detail="Submitting clip to fal queue")
        endpoint = "https://queue.fal.run/fal-ai/wan/v2.7/text-to-video"
        headers = {"Authorization": f"Key {os.environ['FAL_KEY']}", "Content-Type": "application/json"}
        result = requests.post(endpoint, headers=headers, json={"prompt": prompt, "duration": duration,
            "aspect_ratio": "9:16", "resolution": "720p", "enable_prompt_expansion": True}, timeout=30)
        result.raise_for_status()
        response = result.json()
        request_id = response.get("request_id")
        if not request_id:
            raise ValueError("fal did not return a request ID")
        status_url = endpoint + "/requests/" + quote(request_id, safe="") + "/status"
        result_url = endpoint + "/requests/" + quote(request_id, safe="")
        for _ in range(48):
            time.sleep(5)
            poll = requests.get(status_url, headers=headers, timeout=25)
            poll.raise_for_status()
            state = poll.json().get("status", "")
            if state == "COMPLETED":
                break
            set_job(id_, detail=f"fal generation: {state.lower().replace('_', ' ')}")
        else:
            raise TimeoutError("fal video generation exceeded 4 minutes")
        response = requests.get(result_url, headers=headers, timeout=30)
        response.raise_for_status()
        url = response.json().get("video", {}).get("url")
        if not url or not url.startswith("https://"):
            raise ValueError("fal did not return a usable video URL")
        set_job(id_, state="done", detail="Clip generated by fal", url=url)
    except Exception as exc:
        set_job(id_, state="error", detail=f"fal error: {str(exc)[:700]}")

@app.post("/api/fal")
def fal_clip(body: FalRequest):
    if not os.getenv("FAL_KEY"):
        raise HTTPException(400, "Set FAL_KEY to generate optional fal video clips")
    id_ = uuid.uuid4().hex[:16]
    with job_lock:
        JOBS[id_] = {"state": "queued", "detail": "Queued", "url": None, "type": "fal"}
    executor.submit(fal_worker, id_, body.prompt, body.duration)
    return {"id": id_, "state": "queued"}

@app.get("/api/jobs/{id_}")
def job_info(id_: str):
    with job_lock:
        info = JOBS.get(id_)
    if not info:
        raise HTTPException(404, "Job not found")
    return info

@app.get("/api/download/{id_}")
def download(id_: str):
    if id_ not in JOBS or JOBS[id_].get("state") != "done" or JOBS[id_].get("type") != "export":
        raise HTTPException(404, "Video not available")
    path = OUT / id_ / "lesson.mp4"
    if not path.exists():
        raise HTTPException(404, "File not found")
    return FileResponse(path, filename="conceptmotion-lesson.mp4", media_type="video/mp4")
