"""Optional sample-video narration without sponsor keys; requires Linux espeak + ffmpeg.

For the hackathon product, ElevenLabs is the intended higher-quality narrator.
This script is deliberately not part of normal app generation.
"""
import json
import argparse
import subprocess
import tempfile
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parent
lesson=json.loads((ROOT/'samples/disease_model.json').read_text())
parser=argparse.ArgumentParser(description="Add local eSpeak narration to a pre-rendered SIR demo")
parser.add_argument('--input',required=True,help='The 45-second SIR animation MP4')
parser.add_argument('--output',default='narrated-demo.mp4')
args=parser.parse_args()
source=Path(args.input).resolve()
target=Path(args.output).resolve()
if not (shutil.which('espeak') and shutil.which('ffmpeg')):
    raise RuntimeError('espeak and ffmpeg are required for this optional sample')
with tempfile.TemporaryDirectory() as temp:
    p=Path(temp)
    pieces=[]
    for i,scene in enumerate(lesson['scenes']):
        wav=p/f'{i}-raw.wav';clip=p/f'{i}-clip.wav'
        subprocess.run(['espeak','-v','en+f3','-s','160','-w',str(wav),scene['narration']],check=True)
        raw=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(wav)]))
        target_dur=float(scene['duration'])
        # Speed up only if the reading would exceed the allotted scene duration.
        rate=max(1,min(2,raw/(target_dur-.25)))
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(wav),'-af',f'atempo={rate:.4f},apad', '-ac','1','-ar','44100','-t',str(target_dur),str(clip)],check=True)
        pieces.append(clip)
    playlist=p/'list.txt';playlist.write_text(''.join(f"file '{v.as_posix()}'\n" for v in pieces))
    audio=p/'narration.wav'
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(playlist),'-c:a','pcm_s16le',str(audio)],check=True)
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source),'-i',str(audio),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-shortest',str(target)],check=True)
print(target)
