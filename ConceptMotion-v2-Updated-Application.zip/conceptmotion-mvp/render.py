"""Render the same canvas scene engine as the browser preview into a real MP4.

Requires Playwright Chromium and ffmpeg. No Remotion/npm installation required.
"""
from __future__ import annotations
import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright


def render(lesson: dict, output: Path, *, url: str, quality: str="preview", landscape: bool=False, audio: Path|None=None):
    fps, width, height = ((15,360,640) if quality == "preview" else (24,540,960))
    if landscape:
        width,height=height,width
    ffmpeg = os.environ.get("FFMPEG_PATH", "ffmpeg")
    if not shutil.which(ffmpeg):
        raise RuntimeError("Install ffmpeg or set FFMPEG_PATH")
    duration=sum(float(s.get("duration",8)) for s in lesson.get("scenes",[]))
    frames=max(1,round(duration*fps))
    output.parent.mkdir(parents=True,exist_ok=True)
    command=[ffmpeg,"-hide_banner","-loglevel","error","-y","-f","image2pipe","-framerate",str(fps),"-vcodec","png","-i","pipe:0"]
    if audio is not None and audio.exists():
        command += ["-i",str(audio),"-map","0:v:0","-map","1:a:0","-c:a","aac","-b:a","160k","-af","apad","-t",str(duration)]
    command += ["-c:v","libx264","-preset","veryfast","-pix_fmt","yuv420p","-crf","25","-movflags","+faststart",str(output)]
    with sync_playwright() as p:
        # Some minimal environments have full Chromium but not the headless-shell binary.
        chrome_path = Path(p.chromium.executable_path)
        full_chrome = chrome_path.parent.parent / "chrome-linux64" / "chrome"
        launch_args = {"headless": True, "args": ["--no-sandbox", "--disable-dev-shm-usage"]}
        if not chrome_path.exists():
            candidate = str(full_chrome) if full_chrome.exists() else shutil.which("chromium") or shutil.which("google-chrome")
            if candidate:
                launch_args["executable_path"] = candidate
        browser=p.chromium.launch(**launch_args)
        try:
            page=browser.new_page(viewport={"width":width,"height":height},device_scale_factor=1)
            # Offline local asset injection: no network/server access is required to render.
            page.set_content(f"""<html><head><meta charset='utf-8'/></head><body style='margin:0;background:black'>
            <div id='lesson-stage' style='position:relative;width:{width}px;height:{height}px;overflow:hidden;background:black'>
              <canvas id='lesson-canvas' width='{width}' height='{height}' style='display:block;width:{width}px;height:{height}px'></canvas>
              <div id='math-overlay' class='math-overlay'></div>
            </div></body></html>""")
            page.add_style_tag(path=str(Path(__file__).resolve().parent / "static" / "styles.css"))
            page.add_script_tag(path=str(Path(__file__).resolve().parent / "static" / "arc_length.js"))
            page.add_script_tag(path=str(Path(__file__).resolve().parent / "static" / "math.js"))
            page.add_script_tag(path=str(Path(__file__).resolve().parent / "static" / "visuals.js"))
            page.evaluate("window.__cmExportCanvas=document.getElementById('lesson-canvas')")
            proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            try:
                for frame in range(frames):
                    page.evaluate("""([lesson,t]) => {
                      const sceneData=window.ConceptMotionVisuals.draw(window.__cmExportCanvas,lesson,t);
                      const offset=lesson.scenes.slice(0,sceneData.index).reduce((a,s)=>a+Number(s.duration||8),0);
                      window.ConceptMotionMath.draw(document.getElementById('lesson-stage'),sceneData.scene,t-offset);
                    }""",[lesson,frame/fps])
                    pixels=page.locator('#lesson-stage').screenshot(type='png',timeout=25000,animations='disabled')
                    if not proc.stdin:
                        raise RuntimeError("FFmpeg input disappeared")
                    proc.stdin.write(pixels)
                    if frame%100==0:
                        print(f"Rendered {frame}/{frames} frames",flush=True)
                if proc.stdin:
                    proc.stdin.close()
                code=proc.wait(timeout=45)
                if code:
                    raise RuntimeError(f"FFmpeg failed: {proc.stderr.read().decode(errors='replace')[-800:]}")
            except Exception:
                proc.kill()
                raise
        finally:
            browser.close()
    return output

if __name__ == "__main__":
    ap=argparse.ArgumentParser(description="Render a ConceptMotion lesson to MP4")
    ap.add_argument('--lesson',required=True)
    ap.add_argument('--output',required=True)
    ap.add_argument('--url',default='http://127.0.0.1:8000')
    ap.add_argument('--quality',choices=['preview','full'],default='preview')
    ap.add_argument('--landscape',action='store_true')
    ap.add_argument('--audio')
    a=ap.parse_args()
    result=render(json.loads(Path(a.lesson).read_text(encoding='utf-8')),Path(a.output),url=a.url,quality=a.quality,landscape=a.landscape,audio=Path(a.audio) if a.audio else None)
    print(f"MP4 ready: {result}")
