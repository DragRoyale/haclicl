#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python -m playwright install chromium
[ -f .env ] || cp .env.example .env
python -m uvicorn app:app --host 127.0.0.1 --port 8000
