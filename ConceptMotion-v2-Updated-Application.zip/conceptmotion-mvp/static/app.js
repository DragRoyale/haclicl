(function(){
'use strict';
const $=id=>document.getElementById(id),canvas=$('lesson-canvas');
let samples={},lesson=null,playing=false,position=0,lastFrame=0,activeScene=-1,slideText='',slideImages=[],falJobId=null,recorder=null,recordChunks=[],recordStream=null,renderBusy=false;
const icons={population:'♙',compartments:'⇣',diffusion:'⌗',riemann:'∫',slope:'ƒ',landscape:'◉',network:'◎',vectors:'↗',equation:'∑',generic:'✧',arc_length:'⌒'};
function seconds(n){n=Math.max(0,Math.floor(n));return `${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`;}
function totalDuration(l){return (l?.scenes||[]).reduce((a,s)=>a+Number(s.duration||8),0);}
function toast(message){const n=$('toast');n.textContent=message;n.classList.add('show');clearTimeout(n._timeout);n._timeout=setTimeout(()=>n.classList.remove('show'),4400);}
async function getJson(url,opts){const r=await fetch(url,opts);let data;try{data=await r.json()}catch(e){data={detail:`HTTP ${r.status}`}}if(!r.ok)throw new Error(typeof data.detail==='string'?data.detail:JSON.stringify(data.detail||data));return data;}
function buttonBusy(btn,on,busyLabel){if(on){btn.dataset.label=btn.textContent;btn.textContent=busyLabel;btn.disabled=true}else{btn.textContent=btn.dataset.label||btn.textContent;btn.disabled=false}}
function setLesson(l){lesson=l;position=0;playing=false;activeScene=-1;$('play-btn').textContent='▶';$('big-play').classList.remove('hidden');
  $('lesson-heading').textContent=l.title;$('lesson-subheading').textContent=l.subtitle||'Generated visual explanation';
  $('duration-pill').textContent=`${seconds(l.duration||totalDuration(l))} · ${l.scenes.length} scenes`;
  $('scene-count').textContent=`${l.scenes.length} scenes`;$('seek').max=totalDuration(l);$('total-time').textContent=seconds(totalDuration(l));$('seek').value=0;
  $('provider-state').textContent=l.provider==='claude'?'Claude generated':l.provider==='canonical'?'Curated derivation':(l.provider==='demo'||!l.provider)?'Demo template':l.provider;
  $('provider-state').classList.toggle('green',l.provider==='claude');
  buildStoryboard();draw();$('playback-state').textContent='Ready to play';
}
function buildStoryboard(){const root=$('storyboard-list');root.replaceChildren();let offset=0;
 lesson.scenes.forEach((s,i)=>{
  const row=document.createElement('button');row.type='button';row.className='scene-card';row.dataset.scene=String(i);
  const thumb=document.createElement('span');thumb.className='scene-thumb '+s.type;thumb.textContent=icons[s.type]||'✧';
  const main=document.createElement('span');main.className='scene-main';const meta=document.createElement('span');meta.className='scene-meta';
  const idx=document.createElement('span');idx.textContent=`SCENE ${String(i+1).padStart(2,'0')}`;
  const tm=document.createElement('span');tm.className='time';tm.textContent=`${seconds(offset)}–${seconds(offset+Number(s.duration||8))}`;meta.append(idx,tm);
  const title=document.createElement('div');title.className='scene-title';title.textContent=s.title;
  const des=document.createElement('div');des.className='scene-description';des.textContent=s.caption||s.narration;
  main.append(meta,title,des);row.append(thumb,main);
  const when=offset;row.addEventListener('click',()=>{position=when;draw();if(!playing)$('big-play').classList.remove('hidden')});
  root.append(row);offset+=Number(s.duration||8);
 });
}
function draw(){if(!lesson)return;
 const data=window.ConceptMotionVisuals.draw(canvas,lesson,position);
 if(data)window.ConceptMotionMath?.draw($('lesson-stage'),data.scene,position-(lesson.scenes.slice(0,data.index).reduce((a,s)=>a+Number(s.duration||8),0)));
 if(data){$('seek').value=String(position);$('current-time').textContent=seconds(position);
   if(activeScene!==data.index){activeScene=data.index;
    Array.from(document.querySelectorAll('.scene-card')).forEach((r,i)=>r.classList.toggle('active',i===activeScene));
    $('narration-text').textContent=data.scene.narration||'Animation in progress';
   }
 }
}
function animate(now){requestAnimationFrame(animate);if(!playing||!lesson)return;if(!lastFrame)lastFrame=now;
 const dt=Math.min((now-lastFrame)/1000,.15);lastFrame=now;position+=dt;
 const end=totalDuration(lesson);if(position>=end){position=end-.001;playing=false;$('play-btn').textContent='▶';$('big-play').classList.remove('hidden');$('playback-state').textContent='Lesson complete';}
 draw();
}
function toggle(){if(!lesson)return;if(position>=totalDuration(lesson)-.01)position=0;playing=!playing;lastFrame=0;
 $('play-btn').textContent=playing?'Ⅱ':'▶';$('big-play').classList.toggle('hidden',playing);$('playback-state').textContent=playing?'Playing animated lesson':'Paused';
}
async function init(){try{[samples]=await Promise.all([getJson('/api/samples')]);const status=await getJson('/api/health');
  let names=[];if(status.features.claude)names.push('Claude');if(status.features.elevenlabs)names.push('ElevenLabs');if(status.features.fal)names.push('fal');
  $('integration-status').textContent=names.length?`${names.join(' + ')} connected`:'Offline preview ready · add API keys for AI';
  $('fal-badge').textContent=status.features.fal?'fal connected':'fal optional';
  $('use-voice').disabled=!status.features.elevenlabs;$('use-voice').title=status.features.elevenlabs?'Add narrated voice during MP4 export':'Requires ELEVENLABS_API_KEY';
  if(samples.arc_length_formula){setLesson({...samples.arc_length_formula,provider:'canonical'});$('topic').value='Derive the arc length formula from first principles';}
  else if(samples.disease_model)setLesson({...samples.disease_model,provider:'demo'});
  document.querySelectorAll('[data-sample]').forEach(b=>b.addEventListener('click',()=>{
   document.querySelectorAll('[data-sample]').forEach(c=>c.classList.toggle('active',c===b));
   const key=b.dataset.sample;setLesson({...samples[key],provider:key==='arc_length_formula'?'canonical':'demo'});
   $('topic').value=samples[key].title;toast('Preview loaded · this example works without an API key');
  }));
 }catch(err){toast(`Initialization error: ${err.message}`)}
 requestAnimationFrame(animate);
}
$('generate-btn').addEventListener('click',async()=>{
 const btn=$('generate-btn');buttonBusy(btn,true,'✦ Designing your lesson…');$('playback-state').textContent='Generating storyboard';
 try{
  const data=await getJson('/api/lesson',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({topic:$('topic').value,slides:slideText,slide_images:slideImages,transcript:$('transcript').value})});
  setLesson(data);toast(data.provider==='demo'?'Demo storyboard generated; connect Claude for arbitrary topics.':'New storyboard generated by Claude');
 }catch(err){toast(err.message);$('playback-state').textContent='Generation failed'}finally{buttonBusy(btn,false)}
});
$('pdf-file').addEventListener('change',async ev=>{
 const file=ev.target.files?.[0];if(!file)return;const data=new FormData();data.append('file',file);
 $('source-status').textContent='Extracting text from slide PDF…';
 try{const parsed=await getJson('/api/pdf',{method:'POST',body:data});slideText=parsed.text;slideImages=parsed.images||[];
 $('pdf-name').textContent=parsed.filename;$('source-status').textContent=`${parsed.pages} pages loaded. ${parsed.text.length} characters extracted. ${slideImages.length} slide images available to Claude vision.`;
 toast(`${parsed.pages} slide pages ready · now press Generate`);
 }catch(err){toast(err.message);$('source-status').textContent='Slide extraction failed'}
});
async function sendAudio(file){if(!file)return;$('source-status').textContent='Transcribing lecture audio with ElevenLabs…';let fd=new FormData();fd.append('file',file,file.name||'lecture.webm');
 try{const data=await getJson('/api/transcribe',{method:'POST',body:fd});if(!data.text.trim())throw new Error('No speech recognized');$('transcript').value=data.text;$('source-status').textContent='Professor transcript captured. Press Generate to visualize it.';toast('Speech transcribed successfully');}
 catch(err){toast(err.message);$('source-status').textContent='Transcription unavailable; type or paste the professor transcript instead.'}
}
$('audio-file').addEventListener('change',e=>sendAudio(e.target.files?.[0]));
$('record-btn').addEventListener('click',async()=>{
 const b=$('record-btn');
 if(recorder&&recorder.state==='recording'){recorder.stop();if(recordStream)recordStream.getTracks().forEach(tr=>tr.stop());b.textContent='◉ Record explanation';b.classList.remove('recording');return;}
 if(!navigator.mediaDevices?.getUserMedia){toast('Microphone recording requires HTTPS or localhost');return;}
 try{recordStream=await navigator.mediaDevices.getUserMedia({audio:true});recordChunks=[];
  const format=MediaRecorder.isTypeSupported('audio/webm')?'audio/webm':'';
  recorder=new MediaRecorder(recordStream,format?{mimeType:format}:undefined);
  recorder.addEventListener('dataavailable',e=>{if(e.data.size)recordChunks.push(e.data)});
  recorder.addEventListener('stop',()=>{if(recordChunks.length)sendAudio(new File([new Blob(recordChunks,{type:format||'audio/webm'})],'lecture.webm',{type:format||'audio/webm'}))});
  recorder.start();b.textContent='■ Stop recording';b.classList.add('recording');$('source-status').textContent='Recording professor explanation…';
 }catch(err){toast(`Microphone permission: ${err.message}`)}
});
$('play-btn').addEventListener('click',toggle);$('big-play').addEventListener('click',toggle);
$('restart-btn').addEventListener('click',()=>{position=0;playing=false;$('play-btn').textContent='▶';$('big-play').classList.remove('hidden');$('playback-state').textContent='Restarted';draw()});
$('seek').addEventListener('input',e=>{position=Math.max(0,Number(e.target.value));draw()});
$('player-shell').addEventListener('dblclick',toggle);
$('json-btn').addEventListener('click',()=>{
 if(!lesson)return;const url=URL.createObjectURL(new Blob([JSON.stringify(lesson,null,2)],{type:'application/json'}));
 const a=document.createElement('a');a.href=url;a.download='conceptmotion-storyboard.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);
});
async function pollJob(id,target,asVideo=false){let errors=0;for(let i=0;i<180;i++){
  await new Promise(resolve=>setTimeout(resolve,1500));let data;
  try{data=await getJson(`/api/jobs/${id}`)}catch(err){if(++errors>3)throw err;continue}
  target.textContent=data.detail||data.state;
  if(data.state==='done'){if(asVideo){const v=$('fal-player');v.src=data.url;v.style.display='block';target.textContent='fal clip ready · tick the box below to include it in your exported MP4.';$('include-fal').disabled=false;$('include-fal').checked=true;v.load()}
   else{target.textContent='Export ready — downloading MP4';window.location.href=data.url}return}
  if(data.state==='error')throw new Error(data.detail||'Generation failed');
 }throw new Error('Job timed out');}
$('export-btn').addEventListener('click',async()=>{
 if(!lesson||renderBusy)return;renderBusy=true;const b=$('export-btn');buttonBusy(b,true,'Exporting…');const target=$('export-status');
 try{const job=await getJson('/api/export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({lesson,use_voice:$('use-voice').checked,portrait:true,quality:'preview',fal_job_id:$('include-fal').checked?falJobId:null})});
  target.textContent='Rendering MP4 in the background…';await pollJob(job.id,target);
 }catch(err){target.textContent=err.message;toast(err.message)}finally{renderBusy=false;buttonBusy(b,false)}
});
$('fal-btn').addEventListener('click',async()=>{
 if(!lesson)return;const target=$('fal-status'),btn=$('fal-btn');buttonBusy(btn,true,'Generating on fal…');
 const prompt=`Vertical 9:16 educational CGI motion graphic, near-black background, luminous blue cyan and amber 3D illustration, smooth camera, professional minimal scientific design, visually show the concept: ${lesson.title}. Scene: ${lesson.scenes[0]?.title||lesson.title}. No words, no subtitles, no equations, scientifically respectful, soft glow, volumetric light.`;
 try{const job=await getJson('/api/fal',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,duration:5})});falJobId=job.id;target.textContent='fal generation queued…';await pollJob(job.id,target,true);toast('fal clip generated');}
 catch(err){target.textContent=err.message;toast(err.message)}finally{buttonBusy(btn,false)}
});
// The MP4 renderer invokes the SAME canvas renderer at explicit timestamps in headless Chromium.
window.loadRenderLesson=(data,width=540,height=960)=>{canvas.width=width;canvas.height=height;lesson=data;position=0;playing=false;draw()};
window.renderFrame=(t)=>{position=Number(t);draw();return position};
init();
})();
