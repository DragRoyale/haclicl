/* Deterministic arc-length geometry; shares a single coordinate model through all nine stages. */
(function(){
'use strict';
const CYAN='#00E5FF', GOLD='#FFD54A', WHITE='#F8FAFC', GREY='#727987', BG='#000';
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const smooth=v=>{v=clamp(v);return v*v*(3-2*v)};
const curve=x=>x*x/4;
const X=x=>111+239*x;
const Y=y=>826-306*y;
function ln(c,a,b,d,e,color=WHITE,width=2,alpha=1){c.save();c.globalAlpha=alpha;c.beginPath();c.moveTo(a,b);c.lineTo(d,e);c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.stroke();c.restore()}
function tx(c,s,x,y,size=24,color=WHITE,align='center'){c.save();c.font=`${size}px Georgia, 'Times New Roman', serif`;c.textAlign=align;c.textBaseline='middle';c.fillStyle=color;c.fillText(s,x,y);c.restore()}
function dot(c,x,y,r=6,col=GOLD){c.beginPath();c.arc(x,y,r,0,2*Math.PI);c.fillStyle=col;c.fill()}
function axes(c){ln(c,84,845,638,845,GREY,2,.62);ln(c,111,902,111,394,GREY,2,.62);tx(c,'x',636,866,25,GREY);tx(c,'y',94,396,25,GREY);tx(c,'a',110,876,24,GOLD);tx(c,'b',590,876,24,GOLD)}
function drawCurve(c,proportion=1){c.save();c.beginPath();for(let i=0;i<=160*clamp(proportion);i++){let x=2*i/160;if(i===0)c.moveTo(X(x),Y(curve(x)));else c.lineTo(X(x),Y(curve(x)))}c.strokeStyle=CYAN;c.lineWidth=5;c.lineCap='round';c.stroke();c.restore()}
function chords(c,n,proportion=1){c.save();c.beginPath();const visible=Math.max(1,Math.min(n,Math.ceil(n*clamp(proportion))));for(let i=0;i<=visible;i++){let x=2*i/n;if(i===0)c.moveTo(X(x),Y(curve(x)));else c.lineTo(X(x),Y(curve(x)))}c.strokeStyle=WHITE;c.lineWidth=3.2;c.lineJoin='round';c.stroke();c.restore()}
function goldTriangle(c,t=1){const a=smooth(t);if(a<=0)return;const x1=165,y1=764,x2=548,y2=515;c.save();c.globalAlpha=a;
  ln(c,x1,y1,x2,y1,GOLD,4);ln(c,x2,y1,x2,y2,GOLD,4);ln(c,x1,y1,x2,y2,WHITE,5);
  ln(c,x2-18,y1,x2-18,y1-18,GOLD,2);ln(c,x2-18,y1-18,x2,y1-18,GOLD,2);
  dot(c,x1,y1,5,CYAN);dot(c,x2,y2,5,CYAN);
  tx(c,'Δx',357,800,31,GOLD);tx(c,'Δy',589,650,31,GOLD);tx(c,'Δs',335,595,29,WHITE);
  c.restore()}
function title(c,stage){const name={hook:'THE QUESTION',approximation:'THE INTUITION',triangle:'ONE TINY SEGMENT',sum:'ADD ALL THE PIECES',slope:'CONNECT TO SLOPE',substitute:'SUBSTITUTE & SIMPLIFY',limit:'FROM SUM TO INTEGRAL',formula:'WHAT EACH PART MEANS',outro:'THE BIG IDEA'}[stage]||'CURVE LENGTH';
  tx(c,name,360,123,24,CYAN)}
function stageDraw(c,scene,p,t){let st=scene.params?.stage||'hook';
 c.save();c.fillStyle=BG;c.fillRect(0,0,720,1280);
 title(c,st);
 if(st==='hook'){
   const alpha=smooth((t-3.8)/2),r=smooth((t-6.4)/1.4);
   axes(c);c.save();c.beginPath();const length=551;
   for(let i=0;i<=140;i++){const x=2*i/140,u=i/140;
    const straightX=83+length*u,straightY=652;
    const ratio=alpha*(1-r);
    const px=X(x)*(1-ratio)+straightX*ratio,py=Y(curve(x))*(1-ratio)+straightY*ratio;
    if(i===0)c.moveTo(px,py);else c.lineTo(px,py)
   }c.lineWidth=5;c.strokeStyle=CYAN;c.stroke();c.restore();
   if(t>4.4)tx(c,'A flexible string can straighten',360,944,23,GOLD);
 }else if(st==='approximation'){
   axes(c);drawCurve(c);
   if(t>=2 && t<6.4){ln(c,111,826,590,510,GREY,10,.7);tx(c,'One ruler misses the bend',365,925,25,GOLD)}
   if(t>=5){chords(c,6,smooth((t-5)/2));tx(c,'Six little rulers follow it better',360,935,24,GOLD)}
 }else if(st==='triangle'){
   if(t<3){axes(c);drawCurve(c);chords(c,6);tx(c,'Zoom in on a single chord',360,937,26,GOLD)}
   else{goldTriangle(c,smooth((t-3)/1.4));tx(c,'The diagonal has a measurable length',360,915,23,GREY)}
 }else if(st==='sum'){
   axes(c);drawCurve(c);chords(c,8,smooth((t-1)/2.4));
   for(let i=0;i<8;i++){const x=(i+.5)*2/8;
     if(t>3+i*.35)dot(c,X(x),Y(curve(x)),3.7,GOLD)}
   tx(c,'Each chord contributes to total length',360,930,24,GOLD);
 }else if(st==='slope'){
   goldTriangle(c,smooth((t-1)/1.3));tx(c,'slope = rise / run',360,927,30,CYAN);
   if(t>6)tx(c,'Δy ≈ f′(x) Δx',360,988,27,GOLD)
 }else if(st==='substitute'){
   goldTriangle(c,1);tx(c,'Every diagonal uses the same geometry',360,914,24,GREY);
   if(t>7)tx(c,'Factor out (Δx)²',360,968,25,GOLD)
 }else if(st==='limit'){
   axes(c);drawCurve(c);const n=Math.max(8,Math.round(8+(80-8)*smooth((t-1)/6)));chords(c,n);tx(c,`${n} straight segments`,360,937,29,GOLD);
 }else if(st==='formula'){
   c.save();c.translate(143,235);c.scale(.65,.65);axes(c);drawCurve(c);chords(c,26);c.restore();
   tx(c,'Each tiny step becomes a piece of curve length',360,823,22,GREY);
 }else if(st==='outro'){
   drawCurve(c,smooth(t/2));tx(c,'From tiny chords to exact length',360,951,28,GOLD)
 }
 c.restore();
}
window.ConceptMotionArc={draw:stageDraw};
})();
