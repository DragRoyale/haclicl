/* Local, offline MathML formula overlay with per-part timing. Never evaluates user strings. */
(function(){
'use strict';
const ESC=s=>String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
const COMMANDS={Delta:'Δ',delta:'δ',approx:'≈',sum:'∑',int:'∫',cdot:'·',times:'×',infty:'∞',to:'→',leq:'≤',geq:'≥',sqrt:'√',pi:'π',left:'',right:''};
/* Restricted TeX parser supports roots, fractions, bounds, powers, subscripts and primes.
   TeX cannot inject markup: output values are always escaped. */
function texMath(input,parts=[]){
 const src=String(input||'').slice(0,300);let pos=0;
 const matching=parts.filter(v=>v&&v.latex).sort((a,b)=>b.latex.length-a.latex.length);
 const tokenize=(end='', allowMarks=true)=>{
  let out='';while(pos<src.length){let ch=src[pos];if(end&&ch===end){pos++;break}
   if(ch===' '){pos++;continue}
   const mark=allowMarks&&matching.find(v=>src.startsWith(v.latex,pos));
   if(mark){pos+=mark.latex.length;out+=`<mrow data-part="${ESC(mark.id)}">${texMath(mark.latex,[])}</mrow>`;continue}
   let atom='';
   if(ch==='{'||ch==='('||ch==='['){
    if(ch==='{'){pos++;atom=`<mrow>${tokenize('}',allowMarks)}</mrow>`}
    else {pos++;atom=`<mo>${ESC(ch)}</mo>`}
   }else if(ch==='\\'){
    pos++;let cmd='';if(/[a-zA-Z]/.test(src[pos]||'')){while(/[a-zA-Z]/.test(src[pos]||''))cmd+=src[pos++]}else cmd=src[pos++]||'';
    if(cmd==='sqrt'){
     if(src[pos]==='{')pos++;
     atom=`<msqrt>${tokenize('}',allowMarks)}</msqrt>`
    }else if(cmd==='frac'){
     if(src[pos]==='{')pos++;const n=tokenize('}',allowMarks);
     if(src[pos]==='{')pos++;const d=tokenize('}',allowMarks);
     atom=`<mfrac><mrow>${n}</mrow><mrow>${d}</mrow></mfrac>`
    }else if(cmd===','||cmd===';'){atom='<mspace width="0.18em"/>'}
    else atom=COMMANDS[cmd]!==undefined?(COMMANDS[cmd]?`<mo>${ESC(COMMANDS[cmd])}</mo>`:''):`<mi>${ESC(cmd)}</mi>`;
   }else if(ch==='^'||ch==='_'){
    pos++;const script=readScript();
    let previous=out, last='';
    // Wrap the most recent complete MathML node, including nested tags.
    const hit=lastMathNode(out); if(hit){previous=out.slice(0,hit[0]);last=out.slice(hit[0]);}
    out=previous+(ch==='^'?`<msup>${last||'<mi>?</mi>'}<mrow>${script}</mrow></msup>`:`<msub>${last||'<mi>?</mi>'}<mrow>${script}</mrow></msub>`);
    continue
   }else if(/[a-zA-Z]/.test(ch)){pos++;atom=`<mi>${ESC(ch)}</mi>`}
   else if(/[0-9]/.test(ch)){let digits='';while(/[0-9.]/.test(src[pos]||''))digits+=src[pos++];atom=`<mn>${ESC(digits)}</mn>`}
   else {pos++;atom=`<mo>${ESC(ch==='-'?'−':ch)}</mo>`}
   out+=atom;
  }return out;
 };
 function readScript(){if(src[pos]==='{'){pos++;return tokenize('}',allowMarks)}let ch=src[pos]||'';if(ch==='\\'){pos++;let cmd='';while(/[a-zA-Z]/.test(src[pos]||''))cmd+=src[pos++];return `<mi>${ESC(COMMANDS[cmd]||cmd)}</mi>`}pos++;return /[0-9]/.test(ch)?`<mn>${ESC(ch)}</mn>`:`<mi>${ESC(ch)}</mi>`}
 return `<math xmlns="http://www.w3.org/1998/Math/MathML" display="inline"><mrow>${tokenize()}</mrow></math>`;
}
function lastMathNode(source){if(!source)return null;let end=source.length;if(source[end-1]!=='>' )return null;let lastOpen=source.lastIndexOf('<',end-1);let tag=source.slice(lastOpen+1,end-1);if(tag.endsWith('/'))return [lastOpen];if(!tag.startsWith('/'))return [lastOpen];const name=tag.slice(1).trim();let depth=1,at=lastOpen;
 while(depth>0){at=source.lastIndexOf('<',at-1);if(at<0)return [0];let part=source.slice(at+1,source.indexOf('>',at));if(part===`/${name}`)depth++;if(part===name||part.startsWith(`${name} `))depth--;}return [at]
}
function setup(stage){if(!stage)return null;let overlay=stage.querySelector('#math-overlay');if(!overlay){overlay=document.createElement('div');overlay.id='math-overlay';overlay.className='math-overlay';stage.appendChild(overlay)}return overlay}
function getActive(scene,local){const equations=scene.equations||[],events=scene.events||[];if(!equations.length)return null;
 const displayed=events.filter(e=>['show_equation','transform_equation'].includes(e.action)&&e.at<=local).sort((a,b)=>a.at-b.at);
 if(displayed.length===0)return null;
 const event=displayed[displayed.length-1];let eq=equations.find(e=>e.id===event.target)||equations[0];
 const latestHighlight=events.filter(e=>e.action==='highlight_part'&&e.at<=local&&e.target===eq.id&&local<e.at+(e.duration||1.3)).sort((a,b)=>b.at-a.at)[0];
 return {eq,part:latestHighlight?.part||'',at:event.at,transform:event.action==='transform_equation',fromId:event.from_id||''};
}
function draw(stage,scene,local){const layer=setup(stage);if(!layer)return;
 const scale=(stage.clientWidth||720)/720;layer.style.transform=`scale(${scale})`;
 if(!scene||scene.type!=='arc_length'){layer.replaceChildren();layer.dataset.key='';return;}
 const active=getActive(scene,local);
 const transition=active?.transform ? Math.max(0,Math.min(1,(local-active.at)/1.15)) : 1;
 let k=scene.scene_id+'|'+(active?.eq.id||'')+'|'+(active?.part||'')+'|'+(scene.subtitle?.text||'')+'|'+transition.toFixed(2);
 if(layer.dataset.key===k)return;layer.dataset.key=k;layer.replaceChildren();
 function formulaNode(eq,part,opacity=1){
  const formula=document.createElement('div');formula.className='math-formula';formula.dataset.equation=eq.id;
  formula.innerHTML=texMath(eq.latex,eq.parts||[]);
  const length=eq.latex.length;formula.classList.add(length>66?'math-long':length>45?'math-medium':'math-short');
  formula.style.opacity=String(opacity);
  if(part){const node=formula.querySelector(`[data-part="${CSS.escape(part)}"]`);if(node)node.classList.add('gold-highlight')}
  return formula;
 }
 if(active){
  if(transition<1 && active.fromId){
   const old=scene.equations.find(eq=>eq.id===active.fromId);
   if(old)layer.appendChild(formulaNode(old,'',1-transition));
  }
  layer.appendChild(formulaNode(active.eq,active.part,transition));
 }
 const subtitle=scene.subtitle||{};
 const sub=document.createElement('div');sub.className='math-subtitle';
 const message=String(subtitle.text||scene.caption||'');let words=(subtitle.highlight_words||[]).filter(Boolean).map(w=>w.toLowerCase());
 // Highlight complete phrases, not just isolated punctuation-stripped words.
 let cursor=0,parts=[];const phraseRegex=new RegExp('('+words.sort((a,b)=>b.length-a.length).map(w=>w.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')).join('|')+')','gi');
 if(words.length){for(let match of message.matchAll(phraseRegex)){parts.push(document.createTextNode(message.slice(cursor,match.index)));let mark=document.createElement('strong');mark.textContent=match[0];parts.push(mark);cursor=match.index+match[0].length}}
 parts.push(document.createTextNode(message.slice(cursor)));sub.append(...parts);layer.appendChild(sub);
}
window.ConceptMotionMath={draw,texMath};
})();
