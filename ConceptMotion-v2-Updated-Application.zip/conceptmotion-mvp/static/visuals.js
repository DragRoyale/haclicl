/* ConceptMotion's deterministic motion-graphics engine.
   No generated JavaScript is ever executed: only validated storyboard data. */
(function () {
  'use strict';
  const C = {bg:'#05070d', navy:'#111b2d', blue:'#5da8ff', cyan:'#60dbef', orange:'#f1b34b', green:'#3cdbb8', white:'#e9f1ff', muted:'#91a0b9'};
  const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
  const ease=x=>{x=clamp(x);return x*x*(3-2*x);};
  function rr(ctx,x,y,w,h,r,fill,stroke,width=1){
    if(w<=0 || h<=0)return;
    ctx.beginPath();ctx.roundRect(x,y,w,h,Math.min(r,w/2,h/2));
    if(fill){ctx.fillStyle=fill;ctx.fill();}
    if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.stroke();}
  }
  function line(ctx,x1,y1,x2,y2,color,width=1,alpha=1){ctx.save();ctx.globalAlpha=alpha;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();ctx.restore();}
  function ellipse(ctx,x,y,rx,ry,fill,stroke,width=1){ctx.beginPath();ctx.ellipse(x,y,Math.max(.1,rx),Math.max(.1,ry),0,0,Math.PI*2);if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.stroke();}}
  function text(ctx,value,x,y,size=30,color=C.white,align='center',weight='500',maxWidth=600){ctx.font=`${weight} ${size}px Inter,Segoe UI,Arial,sans-serif`;ctx.textAlign=align;ctx.textBaseline='middle';ctx.fillStyle=color;ctx.fillText(String(value||''),x,y,maxWidth);}
  function wrapped(ctx,value,x,y,maxW,size=31,lineH=45,color=C.white,weight='500'){
    const words=String(value||'').split(/\s+/), lines=[];let row='';
    ctx.font=`${weight} ${size}px Inter,Segoe UI,Arial,sans-serif`;
    for(const word of words){const test=(row?row+' ':'')+word;if(ctx.measureText(test).width>maxW&&row){lines.push(row);row=word;}else row=test;}
    if(row)lines.push(row);
    lines.slice(0,4).forEach((l,i)=>text(ctx,l,x,y+i*lineH,size,color,'center',weight,maxW));
  }
  function halo(ctx,x,y,r,color,alpha=.22){let grad=ctx.createRadialGradient(x,y,0,x,y,r);grad.addColorStop(0,hexA(color,alpha));grad.addColorStop(1,hexA(color,0));ctx.fillStyle=grad;ctx.fillRect(x-r,y-r,r*2,r*2);}
  function hexA(hex,alpha){let a=clamp(alpha,0,1);return `rgba(${parseInt(hex.slice(1,3),16)},${parseInt(hex.slice(3,5),16)},${parseInt(hex.slice(5,7),16)},${a})`;}
  function dot(ctx,x,y,r,color,glow=0){if(glow)halo(ctx,x,y,r*4,color,glow);ellipse(ctx,x,y,r,r,color);}
  function arrow(ctx,x1,y1,x2,y2,color,width=4,phase=0){
    line(ctx,x1,y1,x2,y2,color,width,.8);const a=Math.atan2(y2-y1,x2-x1);const head=13;
    line(ctx,x2,y2,x2-head*Math.cos(a-.5),y2-head*Math.sin(a-.5),color,width);
    line(ctx,x2,y2,x2-head*Math.cos(a+.5),y2-head*Math.sin(a+.5),color,width);
    const d=.15+.7*phase;dot(ctx,x1+(x2-x1)*d,y1+(y2-y1)*d,5,color,.34);
  }
  function person(ctx,x,y,s,color,alpha=1){
    ctx.save();ctx.globalAlpha=alpha;halo(ctx,x,y+11*s,19*s,color,.14);
    ellipse(ctx,x,y-10*s,5*s,5*s,color);
    rr(ctx,x-5*s,y-2*s,10*s,17*s,3*s,color);
    line(ctx,x-3*s,y+13*s,x-5*s,y+24*s,color,3*s);line(ctx,x+3*s,y+13*s,x+5*s,y+24*s,color,3*s);
    line(ctx,x-5*s,y+3*s,x-9*s,y+12*s,color,2.4*s);line(ctx,x+5*s,y+3*s,x+9*s,y+12*s,color,2.4*s);
    ctx.restore();
  }
  function floor(ctx,cx,cy,width,height){
    const v=[{x:cx-width/2,y:cy-height*.34},{x:cx+width/2,y:cy-height*.34},{x:cx+width*.66,y:cy+height*.34},{x:cx-width*.34,y:cy+height*.34}];
    ctx.beginPath();v.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle='#111a2b';ctx.fill();ctx.lineWidth=2;ctx.strokeStyle='#2f415d';ctx.stroke();
    ctx.save();ctx.clip();for(let i=-18;i<22;i++){let x=cx-width/2+i*29;line(ctx,x,cy-height,x+width*.5,cy+height*.9,'#24344c',1,.4)}
    for(let j=-12;j<18;j++){let y=cy-height*.75+j*22;line(ctx,cx-width,y,cx+width,y,'#24344c',1,.3)}ctx.restore();
  }
  function backdrop(ctx,t){
    ctx.fillStyle=C.bg;ctx.fillRect(0,0,720,1280);
    const grad=ctx.createRadialGradient(360,620,50,360,620,760);grad.addColorStop(0,'#0e1727');grad.addColorStop(.65,'#080c16');grad.addColorStop(1,'#05070d');ctx.fillStyle=grad;ctx.fillRect(0,0,720,1280);
    halo(ctx,360+60*Math.sin(t*.22),610,420,C.blue,.06);
    for(let k=0;k<80;k++){const x=(k*181+67)%720;const y=(k*283+119)%1280;ellipse(ctx,x,y,1.1,1.1,hexA(C.blue,.11+(Math.sin(k*3+t*.7)+1)*.08));}
    // subtle perspective floor in the lower third
    for(let k=0;k<18;k++){const y=910+k*k*1.17;line(ctx,0,y,720,y,'#1b2b42',1,.25)}
    for(let k=-9;k<=9;k++){line(ctx,360,890,360+k*98,1280,'#1b2b42',1,.22)}
  }
  function topBar(ctx,scene,idx,n,time,total){
    rr(ctx,36,38,195,46,20,'#142238','#274368');dot(ctx,63,61,7,C.cyan,.3);
    text(ctx,'CONCEPTMOTION',78,61,19,C.white,'left','700');
    text(ctx,'VISUAL EXPLAINER',684,61,16,C.muted,'right','600');
    text(ctx,`SCENE ${String(idx+1).padStart(2,'0')} / ${String(n).padStart(2,'0')}`,360,152,19,C.cyan,'center','700');
    wrapped(ctx,scene.title||'Visual explanation',360,213,640,44,53,C.white,'750');
    // progress segments show actual timeline progression
    rr(ctx,36,1160,648,5,3,'#28384e');rr(ctx,36,1160,648*clamp(time/Math.max(.1,total)),5,3,C.cyan);
    const a=Math.floor(time),b=Math.ceil(total);text(ctx,`${Math.floor(a/60)}:${String(a%60).padStart(2,'0')}`,38,1189,19,C.muted,'left');
    text(ctx,`${Math.floor(b/60)}:${String(b%60).padStart(2,'0')}`,683,1189,19,C.muted,'right');
    text(ctx,'THE IDEA, MADE VISIBLE',360,1238,18,'#52718e','center','700');
  }
  function caption(ctx,scene){
    rr(ctx,50,1008,620,105,20,'#0e1728','#25364e',1.5);
    wrapped(ctx,scene.caption || scene.narration?.slice(0,110) || '',360,1050,560,25,33,C.white,'500');
    rr(ctx,292,988,136,4,3,C.cyan);
  }
  function population(ctx,scene,p,t){
    floor(ctx,343,668,410,350);
    const count=Math.min(121,Math.max(25,Number(scene.params?.count||100)));let cols=Math.ceil(Math.sqrt(count));
    const infected=Math.min(count,Number(scene.params?.infected||5));
    for(let j=0;j<Math.ceil(count/cols);j++)for(let i=0;i<cols;i++){
      let k=j*cols+i;if(k>=count)continue;
      const x=135+i*38+j*9,y=529+j*24-i*1.4;
      const noise=(k*37+17)%count;
      const infectionStage=infected+Math.round(p*17);
      const color=noise<infectionStage?C.orange:(noise<infectionStage+Math.round(p*9)?C.green:C.blue);
      let visible=ease(p*5-(k%cols)*.04-j*.025);
      person(ctx,x,y,1.02,color,visible);
      if(noise>=infected&&noise<infectionStage){halo(ctx,x,y+7,13,C.orange,.2)}
    }
    halo(ctx,370,688,175,C.blue,.10);
    [{c:C.blue,name:'SUSCEPTIBLE',n:0},{c:C.orange,name:'INFECTED',n:1},{c:C.green,name:'RECOVERED',n:2}].forEach(a=>{
      const x=43+a.n*222;rr(ctx,x,864,210,55,13,'#101d30','#25405b');dot(ctx,x+22,892,8,a.c,.15);text(ctx,a.name,x+38,892,17,C.white,'left','650');
    });
    text(ctx,'Population dynamics',360,970,24,C.muted);
  }
  function compartments(ctx,scene,p,t){
    const nodes=[{name:'S',full:'SUSCEPTIBLE',col:C.blue,y:405},{name:'I',full:'INFECTED',col:C.orange,y:650},{name:'R',full:'RECOVERED',col:C.green,y:895}];
    nodes.forEach((n,i)=>{
      const appear=ease(p*4-i*.42);ctx.save();ctx.globalAlpha=appear;
      halo(ctx,360,n.y,150,n.col,.14);rr(ctx,238,n.y-59,244,120,22,hexA(n.col,.12),hexA(n.col,.7),2);
      text(ctx,n.name,360,n.y-5,72,n.col,'center','650');
      text(ctx,n.full,360,n.y+44,15,C.muted,'center','700');ctx.restore();
    });
    const pulse=(t*.65)%1;arrow(ctx,360,475,360,573,C.orange,4,pulse);
    arrow(ctx,360,721,360,818,C.green,4,(t*.65+.5)%1);
    rr(ctx,427,512,108,37,9,'#1b1c1c');text(ctx,'βSI',481,531,23,C.orange);
    rr(ctx,427,758,108,37,9,'#142923');text(ctx,'γI',481,777,23,C.green);
  }
  function diffusion(ctx,scene,p,t){
    floor(ctx,340,664,430,415);
    const n=9;
    for(let row=0;row<n;row++)for(let col=0;col<n;col++){
      const x=101+col*49+row*14,y=493+row*28-col*6;
      const dist=Math.hypot(col-4,row-4),radius=1+p*5.5;
      const infection=dist<radius?C.orange:(dist<radius+1?C.green:C.blue);
      const strength=clamp(1-(dist-radius)*1.3,.14,.86);
      ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+45,y-1);ctx.lineTo(x+58,y+21);ctx.lineTo(x+13,y+22);ctx.closePath();ctx.fillStyle=hexA(infection,dist<radius?.22:.08);ctx.fill();ctx.strokeStyle=hexA(infection,.28);ctx.stroke();
      if(dist<radius+2)dot(ctx,x+29,y+9,2.5+strength*3,infection,.12);
    }
    for(let k=0;k<3;k++){
      ctx.save();ctx.globalAlpha=.45-k*.12;
      const r=34+Math.max(0,p*270-60*k);ellipse(ctx,345,646,r,r*.47,null,C.orange,2.5);ctx.restore();
    }
    rr(ctx,150,887,420,62,15,'#101d31','#315277');text(ctx,'SPREAD ACROSS SPACE',360,917,21,C.cyan,'center','700');
  }
  function coordinate(ctx,x0,y0,sx,sy){
    for(let x=0;x<=2.5;x+=.25){let px=x0+x*sx;line(ctx,px,360,px,913,'#23354a',1,.36)}
    for(let y=0;y<=5;y+=.5){let py=y0-y*sy;line(ctx,90,py,625,py,'#23354a',1,.36)}
    line(ctx,90,y0,626,y0,'#9fb0c6',2,.7);line(ctx,x0,928,x0,345,'#9fb0c6',2,.7);
  }
  function riemann(ctx,scene,p,t){
    let x0=133,y0=849,sx=205,sy=106;coordinate(ctx,x0,y0,sx,sy);
    text(ctx,'y = x²',570,355,30,C.cyan,'center','700');
    const nTarget=Math.round(clamp(Number(scene.params?.rectangles||30),4,80));
    const n=Math.max(4,Math.round(4+(nTarget-4)*ease(p)));
    let dw=2/n;
    for(let k=0;k<n;k++){
      const x=k*dw, f=(x+dw/2)**2;
      const rx=x0+x*sx,w=sx*dw,h=sy*f;
      rr(ctx,rx,y0-h,w,Math.max(0,h),0,'rgba(72,190,225,.21)','rgba(96,219,239,.70)',1.2);
    }
    ctx.beginPath();for(let k=0;k<=120;k++){
      const x=k/120*2.2,px=x0+x*sx,py=y0-x*x*sy;
      k?ctx.lineTo(px,py):ctx.moveTo(px,py);
    }ctx.strokeStyle=C.cyan;ctx.lineWidth=5;ctx.stroke();
    halo(ctx,450,630,150,C.cyan,.12);
    rr(ctx,178,900,365,59,14,'#142638','#325472');
    text(ctx,`${n} rectangles  ·  Δx = ${(2/n).toFixed(3)}`,360,930,24,C.white);
  }
  function slope(ctx,scene,p,t){
    let x0=133,y0=869,sx=213,sy=108;coordinate(ctx,x0,y0,sx,sy);
    text(ctx,'f(x) = x²',553,362,29,C.cyan,'center','700');
    let xP=1, baseH=Math.max(.03,Math.min(1.4,Number(scene.params?.h||.6)));
    const h=Math.max(.035,baseH*(1-ease(p))+.035*ease(p));
    const xQ=xP+h,p1={x:x0+xP*sx,y:y0-xP*xP*sy},q={x:x0+xQ*sx,y:y0-xQ*xQ*sy};
    ctx.beginPath();for(let k=0;k<=130;k++){const x=k/130*2.25;k?ctx.lineTo(x0+x*sx,y0-x*x*sy):ctx.moveTo(x0+x*sx,y0-x*x*sy)}ctx.strokeStyle=C.blue;ctx.lineWidth=5;ctx.stroke();
    // Secant line y=(2+h)x-(1+h), in f coordinate system.
    const m=2+h;line(ctx,x0+.3*sx,y0-(1+m*(.3-1))*sy,x0+2.1*sx,y0-(1+m*(2.1-1))*sy,C.orange,3,.7);
    dot(ctx,p1.x,p1.y,9,C.blue,.4);dot(ctx,q.x,q.y,10,C.orange,.5);
    text(ctx,'P',p1.x-18,p1.y-29,24,C.blue,'center','700');text(ctx,'Q',q.x+24,q.y-27,24,C.orange,'center','700');
    rr(ctx,165,922,395,57,13,'#142339','#334d73');text(ctx,`Secant slope ≈ ${(2+h).toFixed(2)}`,362,950,25,C.white);
  }
  function landscape(ctx,scene,p,t){
    const cx=355,cy=660;
    for(let ring=9;ring>=1;ring--){
      const rx=ring*34,ry=ring*17;ellipse(ctx,cx,cy,rx,ry,ring%2?'rgba(41,93,158,.025)':'rgba(68,157,214,.045)',hexA(C.blue,.13+ring*.012),1.6);
    }
    // parabolic landscape mesh
    for(let j=-8;j<=8;j++){
      let pts=[];for(let k=-9;k<=9;k++){
        let x=k/9,y=j/8;pts.push([cx+x*300+y*45,cy+y*170-(-0.38*(x*x+y*y)*140)]);
      }
      pts.forEach((v,i)=>{if(i)line(ctx,...pts[i-1],...v,C.blue,1,.12)})
    }
    const progress=ease(p);
    const path=[];for(let i=0;i<=50;i++){const f=i/50;let x=1.0*Math.pow(1-f,2.2),y=-.55*Math.pow(1-f,2.0);path.push([cx+x*263+y*30,cy+y*145-x*x*55]);}
    for(let i=1;i<path.length*progress;i++)line(ctx,...path[i-1],...path[i],C.orange,4,.8);
    const pt=path[Math.min(50,Math.round(progress*50))];
    halo(ctx,pt[0],pt[1],67,C.orange,.30);dot(ctx,pt[0],pt[1],14,C.orange,.7);
    rr(ctx,178,889,368,69,17,'#101d31','#325271');text(ctx,'LOSS  ↓',362,924,30,C.cyan,'center','700');
  }
  function network(ctx,scene,p,t){
    const counts=[3,5,5,2],xs=[115,276,446,604],ys=counts.map(n=>Array.from({length:n},(_,i)=>490+(i-(n-1)/2)*88));
    for(let layer=0;layer<3;layer++)for(let i=0;i<counts[layer];i++)for(let j=0;j<counts[layer+1];j++){
      const x1=xs[layer],x2=xs[layer+1],y1=ys[layer][i],y2=ys[layer+1][j];
      line(ctx,x1,y1,x2,y2,C.blue,1.6,.12+.10*Math.sin(i+j+layer));
      const motion=((t*.35+layer*.23+i*.09+j*.043)%1);
      if(motion<p*1.5)dot(ctx,x1+(x2-x1)*motion,y1+(y2-y1)*motion,3.5,C.cyan,.25);
    }
    for(let layer=0;layer<4;layer++)for(let i=0;i<counts[layer];i++){
      const x=xs[layer],y=ys[layer][i],color=layer===0?C.blue:(layer===3?C.green:C.cyan);
      halo(ctx,x,y,29,color,.20);dot(ctx,x,y,13,color,.25);
    }
    ['INPUT','HIDDEN 1','HIDDEN 2','OUTPUT'].forEach((v,i)=>text(ctx,v,xs[i],917,17,C.muted,'center','700'));
    rr(ctx,183,971,355,47,12,'#122237','#32516e');text(ctx,'SIGNALS FLOW FORWARD',360,995,21,C.white,'center','700');
  }
  function vectors(ctx,scene,p,t){
    for(let x=100;x<=630;x+=42)line(ctx,x,420,x,870,'#29405b',1,.46);
    for(let y=420;y<=870;y+=42)line(ctx,100,y,630,y,'#29405b',1,.46);
    const cx=357,cy=685;line(ctx,96,cy,630,cy,'#91a4bd',2,.75);line(ctx,cx,875,cx,415,'#91a4bd',2,.75);
    const angle=-.7+Math.sin(t*.55)*.17,x=cx+220*Math.cos(angle),y=cy+220*Math.sin(angle);
    arrow(ctx,cx,cy,x,y,C.cyan,6,.65);
    arrow(ctx,cx,cy,cx+195,cy,C.orange,4,.45);
    const slope=2.2;arrow(ctx,cx,cy,cx-145,cy-80,C.blue,4,.15);
    text(ctx,'x',619,708,25,C.muted);text(ctx,'y',381,434,25,C.muted);
    rr(ctx,195,923,333,58,15,'#14243a','#335171');text(ctx,'DIRECTION + MAGNITUDE',362,951,22,C.white,'center','650');
  }
  function equation(ctx,scene,p,t){
    let formula=String(scene.params?.formula || 'change = input − output').slice(0,90);
    halo(ctx,359,619,315,C.blue,.09);
    rr(ctx,52,460,616,337,27,'#0d1626','#28436a',2);
    rr(ctx,105,495,510,49,13,'#13263a');text(ctx,'THE RELATIONSHIP',361,520,20,C.cyan,'center','700');
    ctx.save();ctx.globalAlpha=ease(p*2);
    const size=formula.length>28?36:formula.length>21?44:55;
    wrapped(ctx,formula,360,621,545,size,76,C.white,'700');ctx.restore();
    line(ctx,151,753,565,753,C.cyan,3,ease(p*2-1));
    for(let k=0;k<4;k++){const x=196+k*105;halo(ctx,x,863,24,k%2?C.orange:C.blue,.16);dot(ctx,x,863,7,k%2?C.orange:C.blue,.25)}
  }
  function generic(ctx,scene,p,t){
    const arr=Array.isArray(scene.params?.labels)?scene.params.labels.slice(0,3):['IDEA','PARTS','CONNECTIONS'];
    const xs=[132,360,588];
    for(let i=0;i<3;i++){
      const y=620+Math.sin(t*1.2+i)*13;let a=ease(p*3-i*.3);
      ctx.save();ctx.globalAlpha=a;
      halo(ctx,xs[i],y,70,[C.blue,C.orange,C.green][i],.17);
      rr(ctx,xs[i]-105,y-77,210,144,22,hexA([C.blue,C.orange,C.green][i],.12),hexA([C.blue,C.orange,C.green][i],.6),2);
      wrapped(ctx,arr[i]||`STEP ${i+1}`,xs[i],y-4,175,22,31,C.white,'650');ctx.restore();
      if(i)arrow(ctx,xs[i]-122,y,xs[i]-133,y,C.cyan,3,(t*.3)%1);
    }
    rr(ctx,122,866,470,68,15,'#142239','#2d4e73');text(ctx,'ONE IDEA, THREE PARTS',360,900,23,C.cyan,'center','700');
  }
  const arc_length=(ctx,scene,progress,t)=>window.ConceptMotionArc?.draw(ctx,scene,progress,t);
  const DRAW={population,compartments,diffusion,riemann,slope,landscape,network,vectors,equation,generic,arc_length};
  function draw(canvas,lesson,seconds){
    if(!canvas || !lesson || !Array.isArray(lesson.scenes) || !lesson.scenes.length)return;
    const ctx=canvas.getContext('2d',{alpha:false});const W=canvas.width,H=canvas.height;
    const scale=Math.min(W/720,H/1280),offX=(W-720*scale)/2,offY=(H-1280*scale)/2;
    ctx.save();ctx.fillStyle=C.bg;ctx.fillRect(0,0,W,H);ctx.translate(offX,offY);ctx.scale(scale,scale);
    let total=lesson.scenes.reduce((a,s)=>a+Number(s.duration||8),0),current=clamp(seconds,0,total-0.0001);
    let offset=0,i=0;for(;i<lesson.scenes.length-1;i++){let duration=Number(lesson.scenes[i].duration||8);if(current<offset+duration)break;offset+=duration;}
    let scene=lesson.scenes[i],local=current-offset,progress=clamp(local/Math.max(1,Number(scene.duration||8)));
    if(scene.type==='arc_length'){
      ctx.fillStyle='#000000';ctx.fillRect(0,0,720,1280);
    } else backdrop(ctx,current);
    try{(DRAW[scene.type]||generic)(ctx,scene,progress,local);}catch(err){generic(ctx,scene,progress,local);}
    if(scene.type==='arc_length'){
      // Uncluttered portrait maths: formula and subtitle live in the same stage.
      rr(ctx,42,1162,636,4,2,'#272727');rr(ctx,42,1162,636*clamp(current/Math.max(.1,total)),4,2,'#00E5FF');
      text(ctx,'CONCEPTMOTION  ·  DERIVATION',360,1208,19,'#8f939d','center','700');
    }else{topBar(ctx,scene,i,lesson.scenes.length,current,total);caption(ctx,scene);}
    ctx.restore();
    return {index:i,time:current,duration:total,scene};
  }
  window.ConceptMotionVisuals={draw,colors:C};
})();
