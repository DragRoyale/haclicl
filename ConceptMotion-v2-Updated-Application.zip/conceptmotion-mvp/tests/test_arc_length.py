"""v2 regression and acceptance checks for the canonical derivation."""
import json
from pathlib import Path
from fastapi.testclient import TestClient
from app import app
from lesson_engine import sample, validate_lesson, SCENE_TYPES

client=TestClient(app)

def test_canonical_arc_length_is_full_100_seconds():
    lesson=sample('arc_length_formula')
    assert lesson['duration']==100
    assert len(lesson['scenes'])==9
    assert [s['params']['stage'] for s in lesson['scenes']] == [
        'hook','approximation','triangle','sum','slope','substitute','limit','formula','outro']
    assert all(s['type']=='arc_length' and s['analogy'] and s['learning_goal'] for s in lesson['scenes'][:8])

def test_formula_terms_have_time_coded_highlights():
    lesson=sample('arc_length_formula')
    highlights=[(s,e) for s in lesson['scenes'] for e in s['events'] if e['action']=='highlight_part']
    assert len(highlights)>=8
    for scene,event in highlights:
        eq=next(q for q in scene['equations'] if q['id']==event['target'])
        assert event['part'] in [p['id'] for p in eq['parts']]
        assert 0 <= event['at'] < scene['duration']
        assert eq['visual_anchor']

def test_legacy_and_v2_validation_compatible():
    sample_old=sample('integral')
    assert sample_old['duration']<=60
    assert all(s['equations']==[] for s in sample_old['scenes'])
    new=sample('arc_length_formula')
    again=validate_lesson(new)
    assert again['duration']==100
    assert again['scenes'][7]['equations'][0]['parts'][1]['id']=='integral'
    assert 'arc_length' in SCENE_TYPES

def test_untrusted_v2_event_actions_are_rejected():
    l=validate_lesson({'title':'X','scenes':[{'type':'arc_length','params':{'stage':'malicious'},
        'duration':10,'events':[{'at':0,'action':'eval','target':'__import__'},
                                 {'at':2,'action':'highlight_part','target':'test','part':'x'}]}]})
    assert l['scenes'][0]['params']['stage']=='hook'
    assert len(l['scenes'][0]['events'])==1
    assert l['duration']<=60

def test_fastapi_exposes_arc_length_demo():
    r=client.get('/api/samples')
    assert r.status_code==200
    assert 'arc_length_formula' in r.json()
    assert r.json()['arc_length_formula']['duration']==100

def test_get_arc_length_without_paid_key(monkeypatch):
    monkeypatch.delenv('ANTHROPIC_API_KEY',raising=False)
    r=client.post('/api/lesson',json={'topic':'derive the arc length formula'})
    assert r.status_code==200
    assert r.json()['provider']=='canonical'
    assert r.json()['duration']==100


def test_renderer_has_shared_stage_capture():
    code=(Path(__file__).resolve().parents[1]/'render.py').read_text()
    assert "page.locator('#lesson-stage').screenshot" in code
    assert 'ConceptMotionMath.draw' in code
