from pathlib import Path
import json
import pytest
from fastapi.testclient import TestClient
from app import app
from lesson_engine import SCENE_TYPES, get_demo, sample, validate_lesson

client=TestClient(app)

@pytest.mark.parametrize('name',['disease_model','integral','derivative','gradient_descent','neural_network'])
def test_samples_are_valid_and_short(name):
    lesson=sample(name)
    assert 30 <= lesson['duration'] <= 60
    assert all(s['type'] in SCENE_TYPES for s in lesson['scenes'])
    assert all(3 <= s['duration'] <= 18 for s in lesson['scenes'])

def test_api_health():
    response=client.get('/api/health')
    assert response.status_code==200
    assert response.json()['features']['preview'] is True

def test_lesson_demo_without_key(monkeypatch):
    monkeypatch.delenv('ANTHROPIC_API_KEY',raising=False)
    r=client.post('/api/lesson',json={'topic':'Explain integrals in a very simple way'})
    assert r.status_code==200
    assert r.json()['scenes'][0]['type']=='riemann'
    assert r.json()['provider']=='demo'

def test_rejects_empty_storyboard():
    with pytest.raises(ValueError):
        validate_lesson({'title':'Untitled','scenes':[]})

def test_dangerous_scene_type_cannot_execute_code():
    payload={'title':'Bad model output','scenes':[{'type':'__import__("os").system("dir")','duration':25,'title':'Test',
             'params':{'inject<script>':'x','formula':'x' * 500}}]}
    sanitized=validate_lesson(payload)
    assert sanitized['scenes'][0]['type']=='generic'
    assert 'inject<script>' not in sanitized['scenes'][0]['params']
    assert len(sanitized['scenes'][0]['params']['formula'])<=120

def test_durations_are_capped_to_one_minute():
    lesson=validate_lesson({'title':'Long','scenes':[{'type':'generic','duration':18} for _ in range(8)]})
    assert lesson['duration'] <= 60

def test_bad_pdf_returns_400():
    r=client.post('/api/pdf',files={'file':('slide.pdf',b'not a real pdf','application/pdf')})
    assert r.status_code==400

def test_pdf_contains_vision_attachment():
    import fitz
    doc=fitz.open()
    page=doc.new_page()
    page.insert_text((72,80),'An example slide: gradients')
    b=doc.tobytes()
    r=client.post('/api/pdf',files={'file':('slide.pdf',b,'application/pdf')})
    assert r.status_code==200
    assert 'gradients' in r.json()['text']
    assert r.json()['images']

def test_export_job_rejects_empty_lesson():
    r=client.post('/api/export',json={'lesson':{'scenes':[]}})
    assert r.status_code==422


def test_claude_request_sends_no_unsupported_temperature(monkeypatch):
    import lesson_engine
    monkeypatch.setenv('ANTHROPIC_API_KEY', 'test-only-key')
    monkeypatch.setenv('CLAUDE_MODEL', 'claude-sonnet-5-5')
    recorded = {}
    class FakeResponse:
        def raise_for_status(self):
            pass
        def json(self):
            return {'content': [{'type': 'text', 'text': json.dumps({
                'title': 'Backpropagation',
                'scenes': [{'type': 'network', 'duration': 9, 'title': 'Error flows backward',
                            'narration': 'Gradients tell each weight how to improve.', 'params': {}}],
            })}]}
    def fake_post(url, *, headers, json, timeout):
        recorded.update({'url': url, 'body': json})
        return FakeResponse()
    monkeypatch.setattr(lesson_engine.requests, 'post', fake_post)
    lesson, provider = lesson_engine.generate('What is backpropagation?')
    assert provider == 'claude'
    assert lesson['scenes'][0]['type'] == 'network'
    assert recorded['body']['model'] == 'claude-sonnet-5-5'
    assert 'temperature' not in recorded['body']
    assert 'top_p' not in recorded['body']
    assert 'top_k' not in recorded['body']

def test_claude_400_error_is_readable(monkeypatch):
    import requests
    import lesson_engine
    monkeypatch.setenv('ANTHROPIC_API_KEY', 'test-only-key')
    class FakeResponse:
        status_code = 400
        def json(self):
            return {'error': {'type': 'invalid_request_error', 'message': 'Invalid temperature parameter'}}
        def raise_for_status(self):
            raise requests.HTTPError('400 Client Error', response=self)
    monkeypatch.setattr(lesson_engine.requests, 'post', lambda *a, **kw: FakeResponse())
    r = client.post('/api/lesson', json={'topic': 'Explain backpropagation'})
    assert r.status_code == 502
    assert 'Claude API returned 400: Invalid temperature parameter' in r.json()['detail']
    assert 'test-only-key' not in r.json()['detail']
